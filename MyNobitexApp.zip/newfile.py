from kivy.app import App
from kivy.uix.label import Label

class TestApp(App):
    def build(self):
        return Label(text='سلام دنیا', font_name='Vazirmatn-Regular.ttf')

TestApp().run()